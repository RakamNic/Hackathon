package Interface;

import java.util.ResourceBundle;
import javax.swing.*;

public class Login extends JFrame {
    Inicio I = new Inicio();
    static String Username, Password;
    static int Level;
    
    public static String getUsername() {
        return Username;
    }

    public static int getLevel() {
        return Level;
    }

    public static String getPassword() {
        return Password;
    }

    public static void setUsername(String Username) {
        Login.Username = Username;
    }

    public static void setPassword(String Password) {
        Login.Password = Password;
    }

    public static void setLevel(int Level) {
        Login.Level = Level;
    }
    
    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    
    public boolean verifCuenta(String Username, String Password){
        int f = DataBase.DBCuentas.getFilas();
        for (int i = 1; i <= f; i++){
            if (Username.equals(DataBase.DBCuentas.getUsername(i)) && Password.equals(DataBase.DBCuentas.getPassword(i))){
                Login.Username = Username; Login.Password = Password; Login.Level = DataBase.DBCuentas.getLevel(i);
                JOptionPane.showMessageDialog(null, "Sesión Iniciada con Éxito");
                return true;
            }
        }
        return false;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TxtUsername = new javax.swing.JLabel();
        TxtPassword = new javax.swing.JLabel();
        TFUsername = new javax.swing.JTextField();
        BTNLogin = new javax.swing.JButton();
        BTNExit = new javax.swing.JButton();
        TFPassword = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Inicio de Sesión");

        TxtUsername.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TxtUsername.setText("Usuario:");

        TxtPassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TxtPassword.setText("Contraseña");

        BTNLogin.setText("Ingresar");
        BTNLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNLoginActionPerformed(evt);
            }
        });

        BTNExit.setText("Salir");
        BTNExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(TxtPassword)
                    .addComponent(TxtUsername))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(BTNLogin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BTNExit))
                    .addComponent(TFUsername, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                    .addComponent(TFPassword))
                .addContainerGap(111, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtUsername)
                    .addComponent(TFUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtPassword)
                    .addComponent(TFPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNLogin)
                    .addComponent(BTNExit))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTNExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_BTNExitActionPerformed

    private void BTNLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNLoginActionPerformed
        String PW = new String (TFPassword.getPassword()).trim();
        if (verifCuenta(this.TFUsername.getText(), PW)){
            this.setVisible(false);
            I.setVisible(true);
        }
        else JOptionPane.showMessageDialog(null, "No se pudo iniciar sesión. \nCompruebe su nombre de Usuario y la Contraseña.");
    }//GEN-LAST:event_BTNLoginActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNExit;
    private javax.swing.JButton BTNLogin;
    private javax.swing.JPasswordField TFPassword;
    private javax.swing.JTextField TFUsername;
    private javax.swing.JLabel TxtPassword;
    private javax.swing.JLabel TxtUsername;
    // End of variables declaration//GEN-END:variables
}
