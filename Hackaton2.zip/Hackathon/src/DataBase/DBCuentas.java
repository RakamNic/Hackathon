package DataBase;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBCuentas {
    static Conexion c = new Conexion();
    static Connection cn;
    
    public static String getUsername(int i){
        String Username = "";
        try{
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String st2 = "SELECT Username FROM Accounts";
            ResultSet rs = st.executeQuery(st2);
            int count = 0;
            while (rs.next()) {
                count++;
                if (count == i) {
                    Username = rs.getString("Username");
                    break;
                }
            }
            rs.close();
            st.close();
        } catch(Exception e){ System.out.println("Ha ocurrido un error: "+e.toString());}
        return Username;
    }
    
    public static String getPassword(int i){
        String Password = "";
        try{
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String st2 = "SELECT Password FROM Accounts";
            ResultSet rs = st.executeQuery(st2);
            int count = 0;
            while (rs.next()) {
                count++;
                if (count == i) {
                    Password = rs.getString("Password");
                    break;
                }
            }
            rs.close();
            st.close();

        } catch(Exception e){ System.out.println("Ha ocurrido un error: "+e.toString());}
        return Password;
    }
    public static int getLevel(int i){
        int Level = 0;
        try{
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String st2 = "SELECT Lv FROM Accounts";
            ResultSet rs = st.executeQuery(st2);
            int count = 0;
            while (rs.next()) {
                count++;
                if (count == i) {
                    Level = Integer.parseInt(rs.getString("Lv"));
                    break;
                }
            }
            rs.close();
            st.close();

        } catch(Exception e){ System.out.println("Ha ocurrido un error: "+e.toString());}
        return Level;
    }
    
    public static void UpdateAccount(String Account, String Username, String Password, int Level){
        try{
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String st2 = "UPDATE Accounts SET Username = '"+Username+"', Password = '"+Password+"', Lv = "+Level+" Where Username = '"+Account+"'";
            int rs = st.executeUpdate(st2);
            st.close();

        } catch(Exception e){ System.out.println("Ha ocurrido un error: "+e.toString());}
    }
    
    public static void AddAccount(String Username, String Password, int Level){
        try{
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String st2 = "Insert into Accounts (Username, Password, Lv) values ('"+Username+"', '"+Password+"', "+Level+")";
            int rs = st.executeUpdate(st2);
            st.close();
        } catch(Exception e){ System.out.println("Ha ocurrido un error: "+e.toString());}
    }
    
    public static void DeleteAccount(String Account){
       try{
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String st2 = "Delete From Accounts Where Username = '"+Account+"'";
            int rs = st.executeUpdate(st2);
            st.close();
        } catch(Exception e){ System.out.println("Ha ocurrido un error: "+e.toString());}
    }
    
    public static int getFilas() {
        int Filas = 0;
        try {
            cn = c.getConectar();
            Statement st = cn.createStatement();
            String query = "SELECT COUNT(*) AS row_count FROM Accounts";
            ResultSet rs = st.executeQuery(query);
            if (rs.next()) {
                Filas = rs.getInt("row_count");
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            System.out.println("Ha ocurrido un error: " + e.toString());
        }
        return Filas;
    }
}