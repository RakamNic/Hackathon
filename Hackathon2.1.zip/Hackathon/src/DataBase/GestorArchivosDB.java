package DataBase;

import static DataBase.DBCuentas.cn;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JFileChooser;

public class GestorArchivosDB {
    Conexion c = new Conexion();
    private Connection conexion;

    public GestorArchivosDB() {
        this.conexion = c.getConectar();
    }

    public void addArchivo(File archivo) {
        if (conexion != null) {
            try {
                String nombreArchivo = archivo.getName();
                FileInputStream archivoStream = new FileInputStream(archivo);

                String sql = "INSERT INTO Archivos (Nombre, Archivo) VALUES (?, ?)";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setString(1, nombreArchivo);
                pstmt.setBinaryStream(2, archivoStream, (int) archivo.length());

                int resultado = pstmt.executeUpdate();
                if (resultado > 0) {
                    JOptionPane.showMessageDialog(null, "Archivo agregado a la base de datos.");
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo agregar el archivo a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                }

                pstmt.close();
                archivoStream.close();
            } catch (SQLException | FileNotFoundException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al agregar el archivo a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GestorArchivosDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    public void AddVideo(String videoname, String url){
        if(conexion != null){
            try{
                
                String sql = "INSERT INTO Fluered.dbo.Videos (Video, URL) VALUES ('" + videoname + "', '" + url + "')";
                
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                
                int resultado = pstmt.executeUpdate();
                if(resultado>0){
                 JOptionPane.showMessageDialog(null, "Archivo agregado a la base de datos.");
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo agregar el archivo a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                
                pstmt.close();
                
            }
                catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al agregar el archivo a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public File getArchivo(int archivoID) {
            try {
                java.sql.Statement stmt = cn.createStatement();
                
                String filename  = "C:\\Users\\erick\\OneDrive\\Desktop\\FlueredFiles";
                
                File folder = new File(filename);
                folder.mkdir();
                String sql = "SELECT Nombre, Archivo FROM Archivos WHERE ID = " + archivoID;
                ResultSet resultado = stmt.executeQuery(sql);

                if (resultado.next()) {
                    String nombreArchivo = resultado.getString("Nombre");
                    InputStream archivoStream = resultado.getBinaryStream("Archivo");

                    File archivoLocal = new File(nombreArchivo);
                    FileOutputStream fos = new FileOutputStream(filename+"\\" +archivoLocal);

                    byte[] buffer = new byte[1024];
                    int longitud;
                    while ((longitud = archivoStream.read(buffer)) != -1) {
                        fos.write(buffer, 0, longitud);
                                                                                                                                                                                                                                                                                                                                                                                         
                    }

                    fos.close();
                    archivoStream.close();

                    return archivoLocal;
                } else {
                    System.out.println("No se encontró ningún archivo con el ID especificado.");
                }

                stmt.close();
            } catch (SQLException | IOException e) {
                e.printStackTrace();
                System.out.println("Error al recuperar el archivo desde la base de datos.");
            }

        return null;
    }
    


    public ArrayList<String[]> getvid() {
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<String[]> strings = new ArrayList<String[]>();
        
        try {
           
            // Consulta SQL para obtener los valores de la base de datos
            String sql = "SELECT * FROM dbo.Videos";
            pstmt = conexion.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                String[] s = new String[2];
                s[0] = rs.getString(1);
                s[1] = rs.getString(2);
                
                strings.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return strings;
    }



    public File seleccionarArchivoPDF() { //Selecciona el archivo desde el ordenador del Usuario
        File archivoSeleccionado = null; //Archivo
        JFileChooser fileChooser = new JFileChooser(); //Ventana de selección de archivo
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); //Selecciona solo archivos, no carpetas
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() { //Filtro, solo acepta pedf
            public boolean accept(File file) {
                return file.getName().toLowerCase().endsWith(".pdf") || file.isDirectory(); //Acepta solo si termina en .pdf
            }

            public String getDescription() {
                return "Archivos PDF (*.pdf)"; //No se hace xd
            }
        });

        int seleccion = fileChooser.showOpenDialog(null); //Verificador de validez de archivo

        if (seleccion == JFileChooser.APPROVE_OPTION) { //Verifica si se aceptó
            archivoSeleccionado = fileChooser.getSelectedFile(); //Le da valor al archivo
            String rutaArchivo = archivoSeleccionado.getAbsolutePath(); //La ruta del archivo
            JOptionPane.showMessageDialog(null, "Has seleccionado: " + rutaArchivo); //Mensaje de aceptación
        }
        return archivoSeleccionado; //Retorna el archivo seleccionado
    }
}