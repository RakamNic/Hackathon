package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    static Connection Conectar = null;
    static String usuario = "sqluser", contrasena = "contra",  bd = "Fluered",  ip = "localhost",  puerto = "1433";
    
    String cadena = "jdbc:sqlserver://"+ip+":"+puerto+"/"+bd;
    
    public Conexion(){
        establecerConexion();
    }
    
    public void establecerConexion(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String cadena = "jdbc:sqlserver://localhost:"+puerto+";"+"databasename="+bd+";TrustServerCertificate=True";
            Conectar = DriverManager.getConnection(cadena, usuario, contrasena);
        } catch (Exception e){ System.out.println("Error de Conexión: "+e.toString()); System.exit(0); }
    }
    
    public Connection getConectar() {
        return Conectar;
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                          