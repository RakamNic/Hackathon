package Interface;

import java.util.ResourceBundle;
import javax.swing.*;

public class Login extends JFrame {
    Inicio I = new Inicio();
    static String Username, Password;
    static int Level;
    
    public static String getUsername() {
        return Username;
    }

    public static int getLevel() {
        return Level;
    }

    public static String getPassword() {
        return Password;
    }

    public static void setUsername(String Username) {
        Login.Username = Username;
    }

    public static void setPassword(String Password) {
        Login.Password = Password;
    }

    public static void setLevel(int Level) {
        Login.Level = Level;
    }
    
    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    
    public boolean verifCuenta(String Username, String Password){
        int f = DataBase.DBCuentas.getFilas();
        for (int i = 1; i <= f; i++){
            if (Username.equals(DataBase.DBCuentas.getUsername(i)) && Password.equals(DataBase.DBCuentas.getPassword(i))){
                Login.Username = Username; Login.Password = Password; Login.Level = DataBase.DBCuentas.getLevel(i);
                JOptionPane.showMessageDialog(null, "Sesión Iniciada con Éxito");
                return true;
            }
        }
        return false;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        BTNExit = new javax.swing.JButton();
        BTNLogin = new javax.swing.JButton();
        TFPassword = new javax.swing.JPasswordField();
        TxtPassword = new javax.swing.JLabel();
        TFUsername = new javax.swing.JTextField();
        TxtUsername = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Inicio de Sesión");

        jPanel1.setBackground(new java.awt.Color(39, 39, 67));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(228, 242, 243));

        BTNExit.setForeground(new java.awt.Color(39, 39, 67));
        BTNExit.setText("Salir");
        BTNExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNExitActionPerformed(evt);
            }
        });

        BTNLogin.setForeground(new java.awt.Color(39, 39, 67));
        BTNLogin.setText("Ingresar");
        BTNLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNLoginActionPerformed(evt);
            }
        });

        TxtPassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TxtPassword.setForeground(new java.awt.Color(39, 39, 67));
        TxtPassword.setText("Contraseña");

        TxtUsername.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TxtUsername.setForeground(new java.awt.Color(39, 39, 67));
        TxtUsername.setText("Usuario:");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Interface/floured-logo-color-2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TxtUsername)
                            .addComponent(TFUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TxtPassword)
                            .addComponent(TFPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(BTNLogin)
                                .addGap(40, 40, 40)
                                .addComponent(BTNExit))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(jLabel3)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TxtUsername)
                .addGap(10, 10, 10)
                .addComponent(TFUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(TxtPassword)
                .addGap(10, 10, 10)
                .addComponent(TFPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BTNLogin)
                    .addComponent(BTNExit))
                .addGap(61, 61, 61))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 60, 330, 360));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Interface/fleured-logo.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 731, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 481, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTNExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_BTNExitActionPerformed

    private void BTNLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNLoginActionPerformed
        String PW = new String (TFPassword.getPassword()).trim();
        if (verifCuenta(this.TFUsername.getText(), PW)){
            this.setVisible(false);
            I.setVisible(true);
        }
        else JOptionPane.showMessageDialog(null, "No se pudo iniciar sesión. \nCompruebe su nombre de Usuario y la Contraseña.");
    }//GEN-LAST:event_BTNLoginActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNExit;
    private javax.swing.JButton BTNLogin;
    private javax.swing.JPasswordField TFPassword;
    private javax.swing.JTextField TFUsername;
    private javax.swing.JLabel TxtPassword;
    private javax.swing.JLabel TxtUsername;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
